import React, { useState } from 'react';

const holyPlaces = [
  { name: 'Nazareth', image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/6/6b/Nazareth_panorama.jpg/640px-Nazareth_panorama.jpg', description: 'Hometown of Jesus, where He spent His youth.' },
  { name: 'Church of the Holy Sepulchre', image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/7/74/Church_of_the_Holy_Sepulchre.jpg/640px-Church_of_the_Holy_Sepulchre.jpg', description: 'Site of the crucifixion and resurrection of Jesus.' },
  { name: 'Sea of Galilee', image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/3/3e/Sea_of_Galilee_from_Mount_of_Beatitudes.jpg/640px-Sea_of_Galilee_from_Mount_of_Beatitudes.jpg', description: 'Where Jesus walked on water and performed miracles.' },
  { name: 'Bethlehem', image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/e/e0/Bethlehem_Panorama.jpg/640px-Bethlehem_Panorama.jpg', description: 'Birthplace of Jesus Christ.' },
  { name: 'Church of All Nations', image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/3/3b/Church_of_All_Nations_Exterior.jpg/640px-Church_of_All_Nations_Exterior.jpg', description: 'Located on the Mount of Olives in Jerusalem.' },
  { name: 'Golgotha', image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/2/2f/Calvary_by_Giotto.jpg/640px-Calvary_by_Giotto.jpg', description: 'Site of the crucifixion of Jesus.' },
  { name: 'Gethsemane', image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/e/e7/Garden_of_Gethsemane_2009.jpg/640px-Garden_of_Gethsemane_2009.jpg', description: 'Where Jesus prayed before His arrest.' },
  { name: 'Church of the Nativity', image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/f/fb/Church_of_the_Nativity_Bethlehem.jpg/640px-Church_of_the_Nativity_Bethlehem.jpg', description: 'Marks the birthplace of Jesus in Bethlehem.' }
];

function App() {
  const [formData, setFormData] = useState({ name: '', email: '', message: '' });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    alert('Prayer request submitted. We will pray for you!');
    setFormData({ name: '', email: '', message: '' });
  };

  return (
    <div className="app">
      <header className="header">
        <h1>The King Jesus Christ</h1>
        <p className="subtitle">"I am the way and the truth and the life." - John 14:6</p>
      </header>

      <section className="places-section">
        <h2>Holy Places</h2>
        <div className="places-grid">
          {holyPlaces.map((place, index) => (
            <div key={index} className="place-card">
              <img src={place.image} alt={place.name} />
              <div className="place-popup">
                <h3>{place.name}</h3>
                <p>{place.description}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className="contact-section">
        <h2>Prayer Request</h2>
        <form onSubmit={handleSubmit} className="contact-form">
          <input type="text" name="name" placeholder="Your Name" value={formData.name} onChange={handleChange} required />
          <input type="email" name="email" placeholder="Your Email" value={formData.email} onChange={handleChange} required />
          <textarea name="message" placeholder="Your Prayer Request" value={formData.message} onChange={handleChange} required></textarea>
          <button type="submit">Send Prayer</button>
        </form>
      </section>

      <footer className="footer">
        <p>Contact us: thekingjesus@gmail.com | +91-99999-99999</p>
        <p>&copy; 2025 The King Jesus Christ. All rights reserved.</p>
      </footer>
    </div>
  );
}

export default App;
